//
//  ViewController.swift
//  MapFilterReduce
//
//  Created by 8KMILES on 16/12/19.
//  Copyright © 2019 8KMILES. All rights reserved.
//

import UIKit
struct  Device {
    var type:String
    var price:Float
    var color:String
}
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        var myiMacpro = Device(type: "iMacPro", price: 5000.00, color:"lightGold")
        var myiphone6 = Device(type: "iPhone", price: 3000.00, color:"white")
        var myiphone7 = Device(type: "iPhone", price: 4000.00, color:"Gold")
        var myiphone8 = Device(type: "iPhone", price: 5000.00, color:"Sliver")
        var myiphonese = Device(type: "iPhone", price: 5000.00, color:"rosegold")
        var mymacair = Device(type: "MacBookAir", price: 5000.00, color:"gray")
        var myDevices=[myiMacpro,myiphone6,myiphone7,myiphone8,myiphonese,mymacair]
       // print("devices are \(myDevices)")

        //This is the old way of doing
        var myPhones:[Device] = []
        for device in myDevices{
            if device.type == "iPhone"{
                myPhones.append(device)
            }
        }
        print("iphones are \(myPhones)")
        //
        
        
        // via filters
        let iphones = myDevices.filter({
            return $0.type=="iPhone"
        })
        print("via filters \(iphones)")
        //
        
        
        //via Map
        //what if you want change all the prices?
        let canadiaPrices:[Float]=myDevices.map({
            return $0.price * 1.5
        })
         print("via map \(canadiaPrices)")
        
        
        //Small code the change to arr to canadiaPrice
        for i in (0...canadiaPrices.count-1) {
           // print (n)
            myDevices[i].price = canadiaPrices[i]
        }

        //Via Reduce
        //What if you want to add all price
        //old way
        var totalPrice:Float=0.0
        for price in canadiaPrices{
            totalPrice += price
        }
        print("old School method \(totalPrice)")
        // new ways
        
        let totalRedceCanadiaprince:Float = canadiaPrices.reduce(0.0, +)
        print("total price via reduce \(totalRedceCanadiaprince)")
        
        //What if you have sum amount can calculate more how much you need more to buy all devices
        let needExtraMoney:Float = canadiaPrices.reduce(1000.0,-)
        print("this much you need to buy \(needExtraMoney)")
        print("devices are \(myDevices)")
        
        
        
       // let listofiphone=myDevices.map(<#T##transform: (Device) throws -> T##(Device) throws -> T#>)
       // let filerexp=myDevices.filter(<#T##isIncluded: (Device) throws -> Bool##(Device) throws -> Bool#>)
       // let reduceExp = myDevices.reduce(<#T##initialResult: Result##Result#>, <#T##nextPartialResult: (Result, Device) throws -> Result##(Result, Device) throws -> Result#>)
    }
    
}

